import Footer from "./components/layout/footer/footer";
import Header from "./components/layout/header/header";
import Product from "./components/product/product";
import Home from "./components/home/home";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./stor/store/store";

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <>
        <Header />
        <Home />
      </>
    ),
  },
  {
    path: "/product/:id",
    element: (
      <>
        <Product />
      </>
    ),
  },
]);

function App() {
  return (
    <>
      <Provider store={store}>
      <RouterProvider router={router} />
      <Footer />
      </Provider>
    </>
  );
}

export default App;
