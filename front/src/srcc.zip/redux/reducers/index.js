import { combineReducers } from "redux";
import allProducts from "./productReducers";

const reducer = combineReducers({
  allProducts: allProducts,
});

export default reducer;
