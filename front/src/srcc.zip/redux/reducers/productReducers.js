import {
  GET_PRODUCTS_FAIL,
  GET_PRODUCTS_SUCCESS,
  GET_PRODUCTS_REQUEST,
} from "../constants/productConstants";

const allProducts = (state = {}, action) => {
  //console.log(action.type);
  switch (action.type) {
    case GET_PRODUCTS_REQUEST:
      console.log("done")
      return state ={
        loading: true,
      };

    case GET_PRODUCTS_SUCCESS:
      return {
        loading: false,
        products: action.payload.products,
      };

    case GET_PRODUCTS_FAIL:
      console.log("fail")
      return state = {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export default allProducts;
