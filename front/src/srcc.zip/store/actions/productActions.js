import {GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAIL, GET_PRODUCTS_REQUEST} from "../constants/productConstant"
import axios from "../axios"

const getProducts = () => async (dispatch) => {
  try {
    dispatch({ type: GET_PRODUCTS_REQUEST})

    const {data} = axios.get("/product")

    dispatch({
      type: GET_PRODUCTS_SUCCESS,
      payload: data,
    })
  } catch (error) {
    dispatch({
      type: GET_PRODUCTS_FAIL,
      payload: error
    })
  }
}


export default getProducts