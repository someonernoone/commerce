import { applyMiddleware, createStore} from "redux"
import { thunk } from "redux-thunk"
import products from "./reducers/index"

const store = createStore(products, {}, applyMiddleware(thunk))


export default store