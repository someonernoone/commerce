import {GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAIL, GET_PRODUCTS_REQUEST} from "../constants/productConstant"



const getProducts = (state = {}, action) => {
  switch(action.type){
    case GET_PRODUCTS_REQUEST:
      return {
        action,
      }
      
    case GET_PRODUCTS_SUCCESS: 
      return {
        action,
      }

    case GET_PRODUCTS_FAIL: 
      return {
        action
      }

    default:
      return state
  }
}


export default getProducts