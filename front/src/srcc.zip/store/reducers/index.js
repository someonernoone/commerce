import { combineReducers } from "redux"
import productReducer from "./productReducers"

const rootReducers = combineReducers({
  products: productReducer
})

export default rootReducers