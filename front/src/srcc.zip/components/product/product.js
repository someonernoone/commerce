import {Avatar } from "@mui/material"
import { useState } from "react"


const product = () => {
  const [value, setValue] = useState(1);
  
  return (
    <>
      <div className="bg-[#fff]">
        <div className="flex p-3 gap-3 items-center sm:flex-row flex-col justify-center">
          <div className="px-5 sm:w-[50%] w-full">
            <img
              className="w-full"
              src="https://images.unsplash.com/photo-1568176579502-3fbc3aacebaf?q=80&w=872&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            />
          </div>
          <div className="sm:w-[50%] py-2 w-full">
            <div className="font-semibold text-xl">Product</div>
            <div
              style={{borderBottom: "1px solid #333"}}
              className="font-sm pb-3 text-sm"
            >
              This product is best{" "}
            </div>
            <div style={{borderBottom: "1px solid #333"}} className="py-4 flex">
              <span className="text-sm font-[300]"> (256 reviews) </span>
            </div>

            <div className="font-bold pt-4 py-3 text-3xl">₹2000</div>

            <div className="flex py-4 gap-5">
              <div className="flex items-center gap-4">
                <button className="border-1 bg-black border-black p-2 text-white">
                  -
                </button>
                <input
                  value={value}
                  type="submit"
                  
                  className="border-none text-center w-[20px] bg-transparent outline-none"
                />
                <button className="border-1 bg-black border-black p-2 text-white">
                  +
                </button>
              </div>
              <button className="px-7 py-2 text-sm text-white rounded-full bg-orange-700">
                Add to cart
              </button>
            </div>
            <div
              style={{borderBottom: "1px solid #333", borderTop: "1px solid #333"}}
              className="py-3 flex"
            >
              <div className="text-lg font-[300]">Status : </div>
              <div className="text-xl text-orange-900 font-semibold">
                OutOfStock
              </div>
            </div>
            <div className="py-4">
              <div className="font-semibold pb-1 text-xl">Discription :-</div>
              <div className="text-sm font-sm">This is a simple product</div>
            </div>
            <div className="py-3">
              <button className="bg-orange-700 text-md text-white py-2 px-8 rounded-full">
                Submit Review
              </button>
            </div>
          </div>
        </div>
        <div className="reviews">
          <div className="flex justify-center">
            <div
              style={{borderBottom: "1px solid #444", display: "inline-block"}}
              className="pt-8 mx-auto sm:px-8 px-5 pb-2 text-[#444] text-center text-2xl"
            >
              Reviews
            </div>
          </div>
          <div
            style={{overflow: "scroll", flex: "none"}}
            className="py-6 gap-3 flex flex-row px-3"
          >
            <div
              style={{flex: "none", border: "1px solid #555"}}
              className="w-[300px] py-3 border-1 border-1 border-[#111]"
            >
              <Avatar />
              <div className="text-md text-center pb-3 font-medium">
                Rohit Patil
              </div>

              <div className="text-sm text-center font-sm">
                1) Habitat: Algae occur in different kinds of habitats like
                fresh water - (Spiro gyra, Oedogo nium etc) or marine water
                (Sarga ssum,Ulva etc.), as phytopan ktons, on soil, on rocks as
                lithophytes, on other endozo oic (Zoochl orella). There are
                about 1800 genera and 21000 species growing all over the world.
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default product;
