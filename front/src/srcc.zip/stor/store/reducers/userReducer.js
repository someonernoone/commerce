import {GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAIL, GET_PRODUCTS_REQUEST} from "../constants/productConstant"


const userReducer = (state, action) => {
  switch (action.type){
    case GET_PRODUCTS_REQUEST:
      console.log("done")
      return {loading: true}

    case GET_PRODUCTS_SUCCESS:
      return {loading: false, user: action.payload}

    case GET_PRODUCTS_FAIL:
      console.log(action)
      return {loading: false, error: action.payload}

    default: 
      return state
  }
}

export default userReducer