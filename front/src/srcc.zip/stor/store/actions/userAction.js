import {GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAIL, GET_PRODUCTS_REQUEST} from "../constants/productConstant"
import axios from "../axios"


const loginRequest =
  () =>
  async (dispatch) => {
    try {
      dispatch({ type: GET_PRODUCTS_REQUEST });

      const { data } = await axios.get("/product");
      

      dispatch({ type: GET_PRODUCTS_SUCCESS, payload: data });
    } catch (error) {
      dispatch({ type: GET_PRODUCTS_FAIL, payload: error.message });
    }
  };

/*const getUserAction = () => async (dispatch) => {
  try {
    dispatch({ type: GET_USER_REQUEST });

    const { data } = await axios.get("/user/getuser");
    
    dispatch({ type: GET_USER_SUCCESS, payload: data });
  } catch (error) {
    dispatch({ type: GET_USER_FAILURE, payload: error.message });
  }
};

const registerRequest = (user) => async (dispatch) => {
  try {
    dispatch({ type: REGISTER_REQUEST})

    const {data} = await axios.post("/user/register", user)

    dispatch({ type: REGISTER_SUCCESS, payload: data})
    
  } catch (error) {
    dispatch({ type: REGISTER_FAILURE, payload: error.message})
  }
}

const addUserChat = (user) => async(dispatch) => {
  
  dispatch({ type: "addUserChat", payload: user})
}

const removeUserChat = () => async(dispatch) => {
  
  dispatch({ type: "removeUserChat", payload: {}})
}

const addNotify = (notify) => async(dispatch) => {

  dispatch({ type: "addNotify", payload: notify})
}

const removeNotify = (notify) => async(dispatch) => {

  dispatch({ type: "removeNotify", payload: notify})
}

export {
  getUserAction,
  loginRequest,
  registerRequest,
  removeUserChat,
  addUserChat,
  addNotify,
  removeNotify
};*/


export default loginRequest
